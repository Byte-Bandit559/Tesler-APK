package com.tesler.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090D16)
private val Panel = Color(0xFF121A29)
private val Blue = Color(0xFF56B9FF)
private val Muted = Color(0xFF9AA8BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("tesler_prefs", MODE_PRIVATE)
        setContent {
            var mode by remember {
                mutableStateOf(prefs.getString("mode", "QUICK") ?: "QUICK")
            }
            TeslerScreen(
                mode = mode,
                onModeChange = {
                    mode = it
                    prefs.edit().putString("mode", it).apply()
                }
            )
        }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeslerScreen(mode: String, onModeChange: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage("I'm TESLER, your phone buddy. My foundation is online. What shall we work on?", false)
            )
        )
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("TESLER", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("YOUR AI PHONE BUDDY", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { }) {
                            Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Muted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                Surface(color = Ink, tonalElevation = 4.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f).background(Panel, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                            singleLine = true,
                            decorationBox = { inner ->
                                if (input.isEmpty()) Text("Message TESLER...", color = Muted)
                                inner()
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val prompt = input.trim()
                                if (prompt.isNotEmpty()) {
                                    messages = messages + ChatMessage(prompt, true) +
                                        ChatMessage(
                                            if (mode == "QUICK")
                                                "I have received that. The local AI brain will be connected in the next milestone."
                                            else
                                                "Let's break that down carefully. The deep-reasoning model will be connected in the next milestone.",
                                            false
                                        )
                                    input = ""
                                }
                            },
                            modifier = Modifier.size(48.dp).background(Blue, CircleShape)
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = "Send", tint = Ink)
                        }
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ModeButton(
                        title = "QUICK MODE",
                        subtitle = "Everyday tasks",
                        selected = mode == "QUICK",
                        icon = { Icon(Icons.Rounded.Bolt, null, tint = if (mode == "QUICK") Blue else Muted) },
                        modifier = Modifier.weight(1f)
                    ) { onModeChange("QUICK") }
                    ModeButton(
                        title = "DEEP MODE",
                        subtitle = "Complex thinking",
                        selected = mode == "DEEP",
                        icon = { Icon(Icons.Rounded.Memory, null, tint = if (mode == "DEEP") Blue else Muted) },
                        modifier = Modifier.weight(1f)
                    ) { onModeChange("DEEP") }
                }

                Spacer(Modifier.height(22.dp))
                Text("YOUR COMPANION", color = Muted, fontSize = 11.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(48.dp).background(Color(0xFF173B59), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("T", color = Blue, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("TESLER is ready", fontWeight = FontWeight.Bold)
                        Text("Foundation build · Local interface", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(8.dp).background(Color(0xFF55D69E), CircleShape))
                }

                Spacer(Modifier.height(20.dp))
                Text("CONVERSATION", color = Muted, fontSize = 11.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(messages) { message ->
                        MessageBubble(message)
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeButton(
    title: String,
    subtitle: String,
    selected: Boolean,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) Color(0xFF1B3045) else Color.Transparent
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(7.dp))
            Column {
                Text(title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else Muted)
                Text(subtitle, fontSize = 9.sp, color = Muted)
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (message.fromUser) Color(0xFF173B59) else Panel,
            shape = RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (message.fromUser) 16.dp else 4.dp,
                bottomEnd = if (message.fromUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.text, modifier = Modifier.padding(14.dp), color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}
